package Mankind;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
//        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//        try {
//            String[] firstLine = reader.readLine().split(" ");
//
//            String firstName = firstLine[0];
//            String lastName = firstLine[1];
//            String facultyId = firstLine[2];
//
//            Student student = new Student(firstName, lastName, facultyId);
//
//            String[] secondLine = reader.readLine().split(" ");
//
//            String firstNameWorker = secondLine[0];
//            String lastNameWorker = secondLine[1];
//            double salary = Double.parseDouble(secondLine[2]);
//            double workingHours = Double.parseDouble(secondLine[3]);
//
//            Worker worker = new Worker(firstNameWorker, lastNameWorker, salary, workingHours);
//
//            System.out.println(student.toString());
//            System.out.println(worker.toString());
//
//        }catch (IllegalArgumentException  error) {
//            System.out.println(error.getMessage());
//        }
    }
}
