package VehiclesExtension;

public interface Drivable {
    String drive(double distance);
    void refuel(double liters);
}