package CarShopExtended;

public interface Sellable extends Car {
    Double getPrice();
}
