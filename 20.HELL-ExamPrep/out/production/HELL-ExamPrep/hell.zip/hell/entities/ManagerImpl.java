package hell.entities;

import hell.entities.heroes.Assassin;
import hell.entities.heroes.Barbarian;
import hell.entities.heroes.Wizard;
import hell.interfaces.Hero;
import hell.interfaces.Manager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManagerImpl implements Manager {

    private Map<String, Hero> localHeroes;

    public ManagerImpl() {
        this.localHeroes = new HashMap<>();
    }

    @Override
    public String addHero(List<String> arguments) {
        String name = arguments.get(0);
        String type = arguments.get(1);

        Hero result = null;


        switch (type) {
            case "Barbarian":
                result = new Barbarian(name);
                break;
            case "Wizard":
                result = new Wizard(name);
                break;
            case "Assassin":
                result = new Assassin(name);
        }
        localHeroes.put(name, result);
        return String.format("Created %s - %s", type, name);
    }

    @Override
    public String addItem(List<String> arguments) {
        return null;
    }

    @Override
    public String addRecipe(List<String> arguments) {
        return null;
    }

    @Override
    public String inspect(List<String> arguments) {
        return null;
    }

    @Override
    public String quit() {
        return null;
    }
}
