package cresla.models;

public class HeatProcessor extends BaseAbsorberModule {
    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
