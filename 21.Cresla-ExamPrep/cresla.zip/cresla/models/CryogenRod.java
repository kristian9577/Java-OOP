package cresla.models;

public class CryogenRod extends BaseEnergyModule  {
    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
