package EventImplementation;

public interface NameChangeListener {
void handleOnNameChanged(Event event);
}
