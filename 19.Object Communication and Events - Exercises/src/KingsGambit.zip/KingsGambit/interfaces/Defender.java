package KingsGambit.interfaces;

public interface Defender {
    String respondToAttack();
}
