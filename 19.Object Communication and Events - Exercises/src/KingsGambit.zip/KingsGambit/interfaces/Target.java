package KingsGambit.interfaces;

public interface Target {
    void onAttacked();
}
