package DependencyInversion;

public interface Operation {
    int execute(int first,int second);
}
