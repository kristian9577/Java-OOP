package BirthdayCelebrations;

public interface Identifiable {
    public String getId();
}
