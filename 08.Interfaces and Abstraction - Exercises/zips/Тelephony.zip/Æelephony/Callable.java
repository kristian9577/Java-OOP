package Тelephony;

public interface Callable {
    String call();
}
