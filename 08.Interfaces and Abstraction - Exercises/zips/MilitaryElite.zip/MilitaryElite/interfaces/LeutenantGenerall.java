package MilitaryElite.interfaces;

public interface LeutenantGenerall {
    public void addPrivate(Private priv);
}
