package MilitaryElite.interfaces;

public interface Commando {
    public void addMission(Mission mission);
}
