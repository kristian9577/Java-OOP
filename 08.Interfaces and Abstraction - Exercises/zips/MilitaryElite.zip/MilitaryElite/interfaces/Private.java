package MilitaryElite.interfaces;

public interface Private extends Soldier {

}
