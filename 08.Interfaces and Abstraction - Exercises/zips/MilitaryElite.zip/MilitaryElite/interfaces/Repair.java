package MilitaryElite.interfaces;

public interface Repair {
    @Override
    public String toString();
}
