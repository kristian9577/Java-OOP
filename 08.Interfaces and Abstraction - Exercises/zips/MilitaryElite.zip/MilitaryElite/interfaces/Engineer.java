package MilitaryElite.interfaces;

public interface Engineer {
    public void addRepair(Repair repair);
}
