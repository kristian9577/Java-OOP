package MilitaryElite.interfaces;

public interface Mission {
    @Override
    public String toString();
}
