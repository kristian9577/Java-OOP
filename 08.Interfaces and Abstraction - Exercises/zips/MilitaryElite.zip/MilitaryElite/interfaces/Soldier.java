package MilitaryElite.interfaces;

public interface Soldier {
    public int getId();
    @Override
    public String toString();
}
