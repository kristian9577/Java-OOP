package MilitaryElite;

import MilitaryElite.application.Engine;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {

        Engine.run();
    }
}
