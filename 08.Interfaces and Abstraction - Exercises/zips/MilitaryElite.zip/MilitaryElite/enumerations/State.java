package MilitaryElite.enumerations;

public enum State {
    inProgress,
    Finished,
}
