package MilitaryElite.enumerations;

public enum Corp {
    Airforces,
    Marines,
}
